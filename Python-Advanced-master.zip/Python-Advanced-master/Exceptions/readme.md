This folder contains the exception functions and their methods
